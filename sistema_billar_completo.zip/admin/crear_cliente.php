<?php
include '../includes/auth.php';
include '../includes/db.php';
require_once '../vendor/phpqrcode/qrlib.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $dni = $_POST['dni'];
    $celular = $_POST['celular'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $stmt = $pdo->prepare("INSERT INTO usuarios (nombre_completo, dni, celular, rol, password) VALUES (?, ?, ?, 'cliente', ?)");
    $stmt->execute([$nombre, $dni, $celular, $password]);

    $filename = "../qrcodes/$dni.png";
    QRcode::png($dni, $filename);

    header("Location: dashboard.php");
    exit;
}
?>
<form method="post" class="p-4">
    <h4>Nuevo Cliente</h4>
    <input type="text" name="nombre" placeholder="Nombre Completo" class="form-control mb-2" required>
    <input type="text" name="dni" placeholder="DNI" class="form-control mb-2" required>
    <input type="text" name="celular" placeholder="Celular" class="form-control mb-2" required>
    <input type="password" name="password" placeholder="Contraseña" class="form-control mb-2" required>
    <button type="submit" class="btn btn-primary">Crear</button>
</form>