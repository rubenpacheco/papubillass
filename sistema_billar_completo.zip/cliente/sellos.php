<?php include '../includes/auth.php'; include '../includes/db.php';
$stmt = $pdo->prepare("SELECT COUNT(*) FROM sellos WHERE usuario_id = ?");
$stmt->execute([$_SESSION['user']['id']]);
$total = $stmt->fetchColumn();
$meta = 5;
?>
<h3>Mis Sellos</h3>
<p>Tienes <?= $total ?> sellos.</p>
<p><?= $total >= $meta ? "¡Ganaste un premio!" : "Te faltan " . ($meta - $total) . " para un premio." ?></p>
<a href="qr.php">Volver al QR</a>